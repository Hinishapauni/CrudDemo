package com.employee.service.crudOperation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.employee.dao.crudOperation.EmployeeRepository;
import com.employee.model.crudOperation.Employee;

public class EmployeeService {
    
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public List<Employee> getAllEmployees(){
		return employeeRepository.findAll();
		
	}
	
	public Employee getEmployeeById(int id) {
		return employeeRepository.findById(id).orElse(null);
		
	}
	
	public Employee createEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}
	
	public Employee updateEmployee(int id,Employee employee,String designation) {
		if(employeeRepository.existsById(id)) {
			employee.setId(id);
			employee.setDesignation(designation);
			return employeeRepository.save(employee);
		}
		return null;
	}
	
	
	public void deleteEmployee(int id) {
		employeeRepository.deleteById(id);
	}
	
}
